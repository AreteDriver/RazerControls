"""Razer Control Center GUI application."""

from .main import main

__all__ = ["main"]
