"""System tray application for Razer Control Center."""

from .main import main

__all__ = ["main"]
