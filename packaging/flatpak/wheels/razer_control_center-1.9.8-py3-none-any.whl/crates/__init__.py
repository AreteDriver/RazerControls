"""Razer Control Center core modules."""
