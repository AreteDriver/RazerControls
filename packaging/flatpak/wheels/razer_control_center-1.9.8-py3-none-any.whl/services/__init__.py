"""Razer Control Center services."""
