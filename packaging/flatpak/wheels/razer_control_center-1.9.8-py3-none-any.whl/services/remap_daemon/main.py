"""Main entry point for the remap daemon."""

from .daemon import main

if __name__ == "__main__":
    main()
